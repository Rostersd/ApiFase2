class Match:
    def __init__(self, match_data):
        self.id = match_data['id']
        self.local_team = match_data['localTeam']
        self.visitor_team = match_data['visitorTeam']
        self.local_goals = match_data['localGoals']
        self.visitor_goals = match_data['visitorGoals']
        self.best_player = match_data['bestPlayer']
        self.first_goal_minute = match_data['firstGoalMinute']
