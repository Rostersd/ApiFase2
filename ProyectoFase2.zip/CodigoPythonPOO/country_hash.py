from hash_table import HashTable

class CountryHash:
    def __init__(self, size):
        self.hash_table = HashTable(size)

    def populate_countries(self, data):
        countries = set()
        for match in data:
            countries.add(match['localTeam'])
            countries.add(match['visitorTeam'])

        for country in countries:
            ascii_value = sum(ord(char) for char in country)
            self.hash_table.insert(country, (ascii_value, country))

    def display_hash_table(self):
        print("Tabla Hash:")
        for index, item in enumerate(self.hash_table.table):
            if item is not None:
                print(f"Posición {index}:")
                for entry in item:
                    print(f"    Clave: {entry[0]}, Valor: {entry[1]}")
            else:
                print(f"Posición {index}: Vacía")
                
    def _calculate_ascii_value(self, country):
        return sum(ord(char) for char in country)
