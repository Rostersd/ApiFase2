class HashTable:
    def __init__(self, size):
        self.size = size
        self.table = [None] * size

    def insert(self, key, value):
        index = self.get_hash_code(key)
        if self.table[index] is None:
            self.table[index] = [(key, value)]
        else:
            self.table[index].append((key, value))

    def get_hash_code(self, key):
        hash_code = 0
        list_of_integers = [ord(char) for char in key]
        for i in list_of_integers:
            hash_code += i
        return hash_code % self.size
