import requests
from match import Match
from country_hash import CountryHash


def main():
    url = "http://localhost:8080/api/match/list"
    try:
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()

            # Creamos una lista para almacenar los objetos Match
            matches = []

            # Creamos objetos Match para cada partido y los almacenamos en la lista
            for match_data in data:
                match = Match(match_data)
                matches.append(match)

            # Creamos un objeto CountryHash y mostramos la tabla hash
            country_hash = CountryHash(21)
            country_hash.populate_countries(data)
            country_hash.display_hash_table()

            # Ahora tienes la lista de objetos Match para usarlos según sea necesario
            print("Partidos almacenados:")
            for match in matches:
                print(f"Partido {match.id}: {match.local_team} vs {match.visitor_team}")

        else:
            print("Error al realizar la solicitud. Código de estado:", response.status_code)
    except requests.exceptions.RequestException as e:
        print("Error de conexión:", e)

if __name__ == "__main__":
    main()
