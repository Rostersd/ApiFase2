class Node:
    def __init__(self, key, match):
        self.key = key
        self.match = match
        self.left = None
        self.right = None

class BinaryTree:
    def __init__(self):
        self.root = None

    def insert(self, key, match):
        if not self.root:
            self.root = Node(key, match)
        else:
            self._insert_recursive(self.root, key, match)

    def _insert_recursive(self, current_node, key, match):
        if key < current_node.key:
            if current_node.left is None:
                current_node.left = Node(key, match)
            else:
                self._insert_recursive(current_node.left, key, match)
        elif key > current_node.key:
            if current_node.right is None:
                current_node.right = Node(key, match)
            else:
                self._insert_recursive(current_node.right, key, match)

    def inorder_traversal(self, node):
        if node:
            self.inorder_traversal(node.left)
            print(f"Key: {node.key}, Match: {node.match}")
            self.inorder_traversal(node.right)

    
