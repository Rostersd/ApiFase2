import requests
from match import Match
from country_hash import CountryHash
from binary_tree import BinaryTree

def calculate_key(match, country_hash):
    local_team_ascii = country_hash._calculate_ascii_value(match.local_team)
    visitor_team_ascii = country_hash._calculate_ascii_value(match.visitor_team)
    total_goals = match.local_goals + match.visitor_goals
    key = local_team_ascii + visitor_team_ascii + total_goals + match.first_goal_minute
    return key

def main():
    url = "http://localhost:8080/api/match/list"
    try:
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()

            # Creamos una lista para almacenar los objetos Match
            matches = []

            # Creamos un objeto CountryHash y mostramos la tabla hash
            country_hash = CountryHash(21)
            country_hash.populate_countries(data)
            country_hash.display_hash_table()

            # Creamos objetos Match para cada partido y los almacenamos en la lista
            for match_data in data:
                match = Match(match_data)
                matches.append(match)

            # Creamos un objeto BinaryTree
            binary_tree = BinaryTree()

            # Insertamos cada partido en el árbol binario utilizando la clave calculada
            for match in matches:
                key = calculate_key(match, country_hash)
                binary_tree.insert(key, match)

            # Realizamos un recorrido inorder para mostrar los datos del árbol
            print("Datos almacenados en el árbol binario:")
            binary_tree.inorder_traversal(binary_tree.root)


            

        else:
            print("Error al realizar la solicitud. Código de estado:", response.status_code)
    except requests.exceptions.RequestException as e:
        print("Error de conexión:", e)

        

if __name__ == "__main__":
    main()
