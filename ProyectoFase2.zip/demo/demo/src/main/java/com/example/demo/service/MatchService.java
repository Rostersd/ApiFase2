package com.example.demo.service;

import com.example.demo.model.Match;
import com.example.demo.repository.MatchRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MatchService {

    @Autowired
    private MatchRepository repo;

    public Match create(Match match) {
        return repo.save(match);
    }

    public List<Match> listMatches() {
        return (List<Match>) repo.findAll();
    }

    public Optional<Match> getMatchById(Long id) {
        return repo.findById(id);
    }

    public Match updateMatch(Long id, Match newMatch) {
        return repo.findById(id)
                .map(match -> {
                    match.setLocalTeam(newMatch.getLocalTeam());
                    match.setVisitorTeam(newMatch.getVisitorTeam());
                    match.setLocalGoals(newMatch.getLocalGoals());
                    match.setVisitorGoals(newMatch.getVisitorGoals());
                    match.setBestPlayer(newMatch.getBestPlayer());
                    match.setFirstGoalMinute(newMatch.getFirstGoalMinute());
                    return repo.save(match);
                })
                .orElseGet(() -> {
                    newMatch.setId(id);
                    return repo.save(newMatch);
                });
    }

    public void deleteMatch(Long id) {
        repo.deleteById(id);
    }
}
