package com.example.demo.controller;


import com.example.demo.model.User;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "api/user")
public class UserController {

    @Autowired
    private UserService service;



    @GetMapping(value = "/test")
    public ResponseEntity<String> testGet(){
        return ResponseEntity.status(HttpStatus.OK).body("test get ejecutadno");

    }

    @PostMapping(value = "/test")
    public ResponseEntity<String> testPost(){
        return ResponseEntity.status(HttpStatus.OK).body("test Post ejecutadno");
    }

    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody User user){
        User createdUser = service.create(user);
        return ResponseEntity.status(HttpStatus.OK).body(createdUser);
    }

    @GetMapping(value = "/list")
    public ResponseEntity<List> listUsers(){
        List<User> list = service.listUsers();
        return ResponseEntity.status(HttpStatus.OK).body(list);

    }

    @PostMapping("/{id}")
    public ResponseEntity<User> updateUser(@PathVariable("id") String id, @RequestBody User newUser){
        User updatedUser = service.updateUser(id, newUser);
        return ResponseEntity.status(HttpStatus.OK).body(updatedUser);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable("id") String id){
        service.deleteUser(id);
        return ResponseEntity.status(HttpStatus.OK).body("Usuario eliminado correctamente");
    }

}
