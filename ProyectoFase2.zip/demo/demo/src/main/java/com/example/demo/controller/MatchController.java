package com.example.demo.controller;

import com.example.demo.model.Match;
import com.example.demo.service.MatchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/api/match")
public class MatchController {

    @Autowired
    private MatchService service;

    @GetMapping("/test")
    public ResponseEntity<String> testGet() {
        return ResponseEntity.status(HttpStatus.OK).body("Test GET ejecutado");
    }

    @PostMapping("/test")
    public ResponseEntity<String> testPost() {
        return ResponseEntity.status(HttpStatus.OK).body("Test POST ejecutado");
    }

    @PostMapping
    public ResponseEntity<Match> createMatch(@RequestBody Match match) {
        Match createdMatch = service.create(match);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdMatch);
    }

    @GetMapping("/list")
    public ResponseEntity<List<Match>> listMatches() {
        List<Match> matches = service.listMatches();
        return ResponseEntity.status(HttpStatus.OK).body(matches);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Match> getMatchById(@PathVariable("id") Long id) {
        return service.getMatchById(id)
                .map(match -> ResponseEntity.status(HttpStatus.OK).body(match))
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Match> updateMatch(@PathVariable("id") Long id, @RequestBody Match newMatch) {
        Match updatedMatch = service.updateMatch(id, newMatch);
        return ResponseEntity.status(HttpStatus.OK).body(updatedMatch);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteMatch(@PathVariable("id") Long id) {
        service.deleteMatch(id);
        return ResponseEntity.status(HttpStatus.OK).body("Partido eliminado correctamente");
    }
}
