package com.example.demo.model;

import jakarta.persistence.*;

@Entity
@Table(name="Partidos")
public class Match {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String localTeam;
    private String visitorTeam;
    private int localGoals;
    private int visitorGoals;
    private String bestPlayer;
    private int firstGoalMinute;

    // Constructor, getters y setters
    // Constructor vacío
    public Match() {
    }

    // Constructor con todos los campos
    public Match(String localTeam, String visitorTeam, int localGoals, int visitorGoals, String bestPlayer, int firstGoalMinute) {
        this.localTeam = localTeam;
        this.visitorTeam = visitorTeam;
        this.localGoals = localGoals;
        this.visitorGoals = visitorGoals;
        this.bestPlayer = bestPlayer;
        this.firstGoalMinute = firstGoalMinute;
    }

    // Getters y setters para todos los campos
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLocalTeam() {
        return localTeam;
    }

    public void setLocalTeam(String localTeam) {
        this.localTeam = localTeam;
    }

    public String getVisitorTeam() {
        return visitorTeam;
    }

    public void setVisitorTeam(String visitorTeam) {
        this.visitorTeam = visitorTeam;
    }

    public int getLocalGoals() {
        return localGoals;
    }

    public void setLocalGoals(int localGoals) {
        this.localGoals = localGoals;
    }

    public int getVisitorGoals() {
        return visitorGoals;
    }

    public void setVisitorGoals(int visitorGoals) {
        this.visitorGoals = visitorGoals;
    }

    public String getBestPlayer() {
        return bestPlayer;
    }

    public void setBestPlayer(String bestPlayer) {
        this.bestPlayer = bestPlayer;
    }

    public int getFirstGoalMinute() {
        return firstGoalMinute;
    }

    public void setFirstGoalMinute(int firstGoalMinute) {
        this.firstGoalMinute = firstGoalMinute;
    }

    @Override
    public String toString() {
        return "Match{" +
                "id=" + id +
                ", localTeam='" + localTeam + '\'' +
                ", visitorTeam='" + visitorTeam + '\'' +
                ", localGoals=" + localGoals +
                ", visitorGoals=" + visitorGoals +
                ", bestPlayer='" + bestPlayer + '\'' +
                ", firstGoalMinute=" + firstGoalMinute +
                '}';
    }
}
