package com.example.demo.service;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    @Autowired
    private UserRepository repo;

    public User create(User user){
        return repo.save(user);
    }

    public List<User> listUsers(){
        return (List<User>) repo.findAll();

    }

    public Optional<User> getUserById(String id) {
        return repo.findById(id);
    }

    public User updateUser(String id, User newUser) {
        return repo.findById(id)
                .map(user -> {
                    user.setName(newUser.getName());
                    user.setTelephone(newUser.getTelephone());
                    return repo.save(user);
                })
                .orElseGet(() -> {
                    newUser.setId(id);
                    return repo.save(newUser);
                });
    }

    public void deleteUser(String id) {
        repo.deleteById(id);
    }
}
